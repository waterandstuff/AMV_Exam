# Screw Detection > Bounding Box Screw Detection
https://universe.roboflow.com/amv-ycxdl/screw-detection-hnff5

Provided by a Roboflow user
License: CC BY 4.0

